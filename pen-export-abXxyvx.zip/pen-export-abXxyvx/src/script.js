// Set the duration of the flip animation

const flipDuration = 5; // in seconds

// Get all the image wrapper elements

const imageWrappers = document.querySelectorAll('.image-wrapper');

// Set the animation delay for each image container

imageWrappers.forEach((imageWrapper, index) => {

  imageWrapper.style.animationDelay = `${index * flipDuration}s`;

});